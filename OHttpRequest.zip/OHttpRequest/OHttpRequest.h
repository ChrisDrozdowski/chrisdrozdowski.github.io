/*------------------------------------------------------------------------------*
* File Name: OHttpRequest.h														*
*																				*
* Version: 1.0.0																*
*																				*
* Created by Chris Drozdowski (drozdowski.chris@gmail.com).						*
*																				*
* Licensed under MIT. License info available in project repository				*
* at https://github.com/chrisdrozdowski.										*
*																				*
*------------------------------------------------------------------------------*/
#ifndef __OHTTPREQUEST_H__
#define __OHTTPREQUEST_H__

#ifdef WIN32 // In VC.
#define EXPORT_SYMBOL __declspec(dllexport)
#ifndef __cplusplus
#define CEXPORT EXPORT_SYMBOL
#else
#define CEXPORT extern "C" EXPORT_SYMBOL
#endif

#include "stdafx.h"

#else // In Origin C.
#define CEXPORT
#ifdef _O64
#pragma dll(ohttprequest_64, header)
#else
#pragma dll(ohttprequest, header)
#endif

#endif

// Values returned by call to OHttpRequest.
// Can be used in Origin C.
enum {
	OHTTPREQ_ERR_MEMORY_ERROR = -99,	// Memory allocation error.
	OHTTPREQ_ERR_NOT_EXEC,				// Request not executed yet.
	OHTTPREQ_ERR_INVALID_URL,			// URL is empty or invalid for some reason.
	OHTTPREQ_ERR_WIN_HTTP_ERROR,		// Some sort of internal Windows HTTP API error.
	OHTTPREQ_ERR_CANNOT_CONNECT,		// Cannot connect to server when sending request.
	OHTTPREQ_ERR_SSL_ERROR,				// Some sort of issue related to SSL and certificates when sending request.
	OHTTPREQ_ERR_SEND_RECEIVE_ERROR,	// Any other error when sending data to or receiving data from server.
	OHTTPREQ_ERR_PROXY_ERROR,			// Error while resolving potential proxy.
	OHTTPREQ_ERR_PROXY_AUTH_FAIL,		// Proxy authentication failed due to bad or missing credentials.
	OHTTPREQ_ERR_NO_ERROR = 0,			// No error- successful request.
};

// HTTP request methods.
// Can be used in Origin C.
enum {
	OHTTPREQ_METHOD_AUTO_GET_OR_POST = 0,	// Use POST if there is a request body, otherwise use GET. This is default.
	OHTTPREQ_METHOD_HEAD,
	OHTTPREQ_METHOD_OPTIONS,
	OHTTPREQ_METHOD_PUT,
	OHTTPREQ_METHOD_PATCH,
	OHTTPREQ_METHOD_DELETE,
};

// Constants used for defaults.
// Not meant for Origin C- only for DLL code.
#define	OHTTPREQ_DEF_HTTP_STATUS		0							// The Default HTTP status set prior to request actually being made.
#define	OHTTPREQ_STR_DEF_USER_AGENT		"OriginLab-OHttpRequest"	// This is the default user agent for the request.

// Size of memory allocation block for processing response body.
// Not meant for Origin C- only for DLL code.
#define OHTTPREQ_MEM_ALLOC_SIZE		8196;


// Definition of struct to pass in to OHttpRequest function.
// Can be used in Origin C.
#pragma pack(push, 1)
typedef struct {
	int nError;						// [Output] One of the OHTTPREQ_ERR_* enums. It is same value as returned by OHttpRequest function.
	int nMethod;					// [Input] Required. One of the OHTTPREQ_METHOD_* enums.
	LPCSTR lpszUrl;					// [Input] Required. Full URL inc. HTTP scheme, resource variables, and query string.
											// If no port is specified, then port is automatically determined.
											// If encoding of resource variables or query string names & values is needed,
											// it should be done prior to calling the OHttpRequest function.
	LPCSTR lpszRequestHeaders;		// [Input] Optional. Should be NULL if empty.
											// Null-terminated string of name:value pairs of request headers each seperated by \r\n.
											// There should be NO \r\n after last header per MS docs.
	LPCSTR lpszRequestBody;			// [Input] Optional. Should be NULL if empty.
											// Null-terminated string containing body to send with request (e.g. POST variables or raw POST).
											// If encoding is needed, it should be done prior to calling the request-making function.
	LPCSTR lpszUserAgent;			// [Input] Optional. Should be NULL if empty.
											// Null-terminated string containing the User Agent to use for request.
											// If not specified, then OHTTPREQ_STR_DEF_USER_AGENT is used.
	int nConnectTimeout;			// [Input] Required. Timeout in seconds.
											// Microsoft suggests 60 seconds.
											// BUT you don't have to actually specify a value because when an instance of the struct
											// is created, the value will be set to 0 by default (int defaults to 0), so it WILL have a value.
											// Note though that 0 means no timeout- it will take as long as necessary.
	int nSendTimeout;				// [Input] Required. Timeout in seconds.
											// Microsoft suggests 30 seconds.
											// BUT you don't have to actually specify a value because when an instance of the struct
											// is created, the value will be set to 0 by default (int defaults to 0), so it WILL have a value.
											// Note though that 0 means no timeout- it will take as long as necessary.
	int nResponseTimeout;			// [Input] Required. Timeout in seconds.
											// Microsoft suggests 30 seconds.
											// BUT you don't have to actually specify a value because when an instance of the struct
											// is created, the value will be set to 0 by default (int defaults to 0), so it WILL have a value.
											// Note though that 0 means no timeout- it will take as long as necessary.
	BOOL bAcceptCompressed;			// [Input] Required. Flag to specify acceptance of compressed response data.
											// You don't have to actually specify a value because when an instance of the struct
											// is created, the value will be set to 0 by default (BOOL defaults to 0), so it WILL have a value.
											// Important!!! WinHTTP  for Windows 7 & Windows 8 does NOT support response compression.
											// Response compression is only supported in Windows 8.1 or greater.
											// But you can set this to TRUE and it will be happily ignored for Win 7 & 8. So no worries
											// about figuring out which version of Windows is running.
	BOOL bIgnoreSslIssues;			// [Input] Required. Flag to specify that SSL related errors be ignored.
											// You don't have to actually specify a value because when an instance of the struct
											// is created, the value will be set to 0 by default (BOOL defaults to 0), so it WILL have a value.
	LPCSTR lpszProxyUser;			// [Input] Optional. Should be NULL if empty.
											// Proxy server authentication user name. The actual value- not pre-encoded/encrypted.
	LPCSTR lpszProxyPassword;		// [Input] Optional. Should be NULL if empty.
											// Proxy server authentication password. The actual value- not pre-encoded/encrypted.
	int nHttpStatus;				// [Output] HTTP response status from the request.
											// Default OHTTPREQ_DEF_HTTP_STATUS if no status is returned for some reason.
	LPSTR lpszResponseHeaders;		// [Output] Null-terminated string of name:value pairs of response headers each seperated by \r\n.
											// WinHTTP WILL add \r\n after last header. Different from request headers which don't end in \r\n.
	LPBYTE lpbResponseBody;			// [Output] Byte array containing response body returned from request.
											// It is NOT null-terminated to allow for binary data to be returned.
											// If converting to a string, you will have to null terminate manually.
											// Note: It may be empty!!!
	DWORD dwResponseSize;			// [Output] Count of bytes in response body byte array.
} OHTTPREQUESTPARAMS;
#pragma pack(pop)


// A note about proxy support:
// Proxy support is a real pain!
// This code does NOT automatically pick up proxy settings from Origin 2019 or greater. (This allows for decoupling
// from the specifics of whatever Origin does- fewer potential issues.)
// Rather, it automatically queries Windows for proxy settings first by looking at those set in the
// Internet Options Control Panel, then for other proxy settings that may be set at the Windows level.
// That being the case, you may still have to provide a proxy user name and password in the struct if
// Windows doesn't have default user name and password settings.

// Origin C callable function that makes the HTTP request.
// Accepts a pointer to an OHTTPREQUESTPARAMS struct.
// Optionally accepts an integer pointer that can be set to the value
// of Win API GetLastError() in the function (in case it is needed in Origin C).
// Returns one of OHTTPREQ_ERR_* enumerations.
// A sucessful request return would be OHTTPREQ_ERR_NO_ERROR.
// Note: OHttpRequestCleanParamsStruct MUST be called prior to an instance
// of OHTTPREQUESTPARAMS going out of scope to avoid memory issues.
CEXPORT int OHttpRequest(LPVOID pBuf, int* pnGetLastError = NULL);

// Origin C callable function that must be called this after calling OHttpRequest to
// free memory allocated to an instance of OHTTPREQUESTPARAMS used in that call.
// You cannot free this memory in Origin C due to potential differences
// in the runtime library being used.
CEXPORT int OHttpRequestCleanParamsStruct(LPVOID pBuf);

#endif //__OHTTPREQUEST_H__
