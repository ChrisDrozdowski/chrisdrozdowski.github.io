/*------------------------------------------------------------------------------*
 * File Name: OHash.h															*
 *																				*
 * Version: 1.0.0																*
 *																				*
 * A small library of functions for generating various types of hashes			*
 * in Origin C.																	*
 *																				*
 * Created by Chris Drozdowski (drozdowski.chris@gmail.com).					*
 *																				*
 * Licensed under MIT. License info available in project repository				*
 * at https://github.com/chrisdrozdowski.										*
 *																				*
 *------------------------------------------------------------------------------*/
#ifndef __OHASH_H__
#define __OHASH_H__

#ifdef WIN32 // In VC.
#define EXPORT_SYMBOL __declspec(dllexport)
#ifndef __cplusplus
#define CEXPORT EXPORT_SYMBOL
#else
#define CEXPORT extern "C" EXPORT_SYMBOL
#endif

#include "stdafx.h"

#else // In Origin C.
#define CEXPORT
#ifdef _O64
#pragma dll(ohash_64, header)
#else
#pragma dll(ohash, header)
#endif

#endif

// Supported Hashing algorithm types.
enum {
	OHASH_HASH_MD5 = 0,
	OHASH_HASH_SHA1,
	OHASH_HASH_SHA256,
	OHASH_HASH_SHA384,
	OHASH_HASH_SHA512
};

// Length in characters for hash in hex string form.
#define OHASH_HASH_MD5_HEX_LEN		32
#define OHASH_HASH_SHA1_HEX_LEN		40
#define OHASH_HASH_SHA256_HEX_LEN	64
#define OHASH_HASH_SHA384_HEX_LEN	96
#define OHASH_HASH_SHA512_HEX_LEN	128

// Creates hex encoded string hash optioanlly accepting a secret string to generate HMAC.
// Returns length of lpzOut without any NULL terminator or -1 if error.
// nOutSize is input param indicating size of buffer to receive result.
CEXPORT int OHashGenerateHash(int nAlgId, LPCSTR lpczIn, LPSTR lpzOut, int nOutSize, LPCSTR lpczSecret = NULL);

#ifndef WIN32 // In Origin C.

// In Origin C code.
// ================

#pragma dll() // Closes #pragma dll(ohash(_64), header) opened above.

// Origin C function returns a hex-encoded hash of the input string using
// one of the hashing algorithms defined in the OHASH_HASH_* enumeration.
string OGenerateHash(int nAlgId, LPCSTR lpczIn)
{
	return _DoGenerateHash(nAlgId, lpczIn, NULL);
}

// Origin C function returns a hex-encoded HMAC of the input string and secret string using
// one of the hashing algorithms defined in the OHASH_HASH_* enumeration.
string OGenerateHMAC(int nAlgId, LPCSTR lpczIn, LPCSTR lpczSecret)
{
	return _DoGenerateHash(nAlgId, lpczIn, lpczSecret);
}


// Returns a Base64-encoded string.
// Adapted from original code by William Sherif (will.sherif@gmail.com): https://github.com/superwills/NibbleAndAHalf
string OBase64Encode(LPCSTR lpczIn)
{
	const char* pch64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	int nLength = strlen(lpczIn);

	if (!nLength)
		return "";

	int nPad = (((nLength % 3) & 1) << 1) + (((nLength % 3) & 2) >> 1);

	const char* pchIn = lpczIn;

	string strOut;
	char* pchOut = strOut.GetBuffer((4 * (nLength + nPad) / 3));

	int ii = 0;
	int jj = 0;

	for (ii = 0; ii <= nLength - 3; ii += 3)
	{
		unsigned char CHAR0 = pchIn[ii];
		unsigned char CHAR1 = pchIn[ii + 1];
		unsigned char CHAR2 = pchIn[ii + 2];
		pchOut[jj++] = pch64[CHAR0 >> 2];
		pchOut[jj++] = pch64[((0x3 & CHAR0) << 4) + (CHAR1 >> 4)];
		pchOut[jj++] = pch64[((0x0f & CHAR1) << 2) + (CHAR2 >> 6)];
		pchOut[jj++] = pch64[0x3f & CHAR2];
	}

	if (2 == nPad)
	{
		pchOut[jj++] = pch64[pchIn[ii] >> 2];
		pchOut[jj++] = pch64[(0x3 & pchIn[ii]) << 4];
		pchOut[jj++] = '=';
		pchOut[jj++] = '=';
	}
	else if (1 == nPad)
	{
		pchOut[jj++] = pch64[pchIn[ii] >> 2];
		pchOut[jj++] = pch64[((0x3 & pchIn[ii]) << 4) + (pchIn[ii + 1] >> 4)];
		pchOut[jj++] = pch64[(0x0f & pchIn[ii + 1]) << 2];
		pchOut[jj++] = '=';
	}

	strOut.ReleaseBuffer();

	return strOut;
}

// Static functions.

static string _DoGenerateHash(int nAlgId, LPCSTR lpczIn, LPCSTR lpczSecret)
{
	if (!lpczIn || 0 == strlen(lpczIn))
		return "";

	if (lpczSecret && 0 == strlen(lpczSecret))
		lpczSecret = NULL;

	int nSize;
	switch (nAlgId)
	{
	case OHASH_HASH_MD5:
		nSize = OHASH_HASH_MD5_HEX_LEN;
		break;

	case OHASH_HASH_SHA1:
		nSize = OHASH_HASH_SHA1_HEX_LEN;
		break;

	case OHASH_HASH_SHA256:
		nSize = OHASH_HASH_SHA256_HEX_LEN;
		break;

	case OHASH_HASH_SHA384:
		nSize = OHASH_HASH_SHA384_HEX_LEN;
		break;

	case OHASH_HASH_SHA512:
		nSize = OHASH_HASH_SHA512_HEX_LEN;
		break;

	default:
		return ""; // Return empty on unsupported algorithm.
		break;
	}

	nSize++; // Add 1 for NULL terminator.

	string str;
	LPSTR lpsz = str.GetBuffer(nSize);
	memset(lpsz, 0, nSize);

	int nRet = OHashGenerateHash(nAlgId, lpczIn, lpsz, nSize, lpczSecret);
	str.ReleaseBuffer();

	if (-1 == nRet)
		return "";

	return str;
}


#endif // Last #ifndef WIN32.

#endif //__OHASH_H__
