/*------------------------------------------------------------------------------*
 * File Name: OJsonFuncs.h														*
 *																				*
 * Version: 1.0.0																*
 *																				*
 * A small library of functions for manipulating strigifed JSON data			*
 * in Origin C.																	*
 *																				*
 * Created by Chris Drozdowski (drozdowski.chris@gmail.com).					*
 *																				*
 * Licensed under MIT. License info available in project repository				*
 * at https://github.com/chrisdrozdowski.										*
 *																				*
 *------------------------------------------------------------------------------*/
#ifndef __OJSONFUNCS_H__
#define __OJSONFUNCS_H__

#ifdef WIN32 // In VC.
#define EXPORT_SYMBOL __declspec(dllexport)
#ifndef __cplusplus
#define CEXPORT EXPORT_SYMBOL
#else
#define CEXPORT extern "C" EXPORT_SYMBOL
#endif

#include "stdafx.h"

#else // In Origin C.
#define CEXPORT
#ifdef _O64
#pragma dll(ojsonfuncs_64, header)
#else
#pragma dll(ojsonfuncs, header)
#endif

#endif


// Sanitizes keys in JSON string so they are valid C identifiers.
// Accepts a pointer to string for input and a pointer to pointer to a string for output.
// Returns size of output string w/o NULL terminator or -1 if memory error.
// (Note: Must call OJsonCleanMemory after using this function to free memory allocated for lpzOut.)
CEXPORT int OJsonSanitizeKeys(LPCSTR lpczIn, LPSTR* lpzOut);

// Encloses unquoted numeric values in JSON string with quotes.
// Accepts a pointer to string for input and a pointer to pointer to a string for output.
// Returns size of output string w/o NULL terminator or -1 if memory error.
// (Note: Must call OJsonCleanMemory after using this function to free memory allocated for lpzOut.)
CEXPORT int OJsonQuoteNumericValues(LPCSTR lpczIn, LPSTR* lpzOut);

// Origin C callable function that must be called this after calling other functions
// in this library that return a string whose memory was allocated in the DLL.
// You cannot free this memory in Origin C due to potential differences
// in the runtime library being used.
CEXPORT int OJsonCleanMemory(LPSTR lpz);

#ifndef WIN32 // In Origin C.

// In Origin C code.
// ================

#pragma dll() // Closes #pragma dll(ojsonfuncs(_64), header) opened above.


// Function iterates a JSON string sanitizing the keys into valid C identifiers
// by replacing invalid characters with underscore (_).
// If key begins with number, an underscore is prepended before the number.
string JsonSanitizeKeys(const string& strIn)
{
	LPSTR lpzOut;
	string strOut;

	if (OJsonSanitizeKeys(strIn, &lpzOut))
	{
		strOut = lpzOut;
		OJsonCleanMemory(lpzOut);
	}

	return strOut;
}

// Function iterates a JSON string enclosing unquoted numeric values in quotes (").
// Returns size of output string w/o NULL terminator or -1 if memory error.
string JsonQuoteNumericValues(const string& strIn)
{
	LPSTR lpzOut;
	string strOut;

	if (OJsonQuoteNumericValues(strIn, &lpzOut))
	{
		strOut = lpzOut;
		OJsonCleanMemory(lpzOut);
	}

	return strOut;
}

//END OC CODE


#endif // Last #ifndef WIN32.

#endif //__OJSONFUNCS_H__
