/*------------------------------------------------------------------------------*
 * File Name: ORestClient.h														*
 *																				*
 * Version: 1.0.0															*
 *																				*
 * Minimum Origin version: 2018 (9.5)											*
 *																				*
 * Created by Chris Drozdowski (drozdowski.chris@gmail.com)						*
 *																				*
 * Licensed under MIT. License info available in project repository				*
 * at https://github.com/chrisdrozdowski.										*
 * 																				*
 * It uses Microsoft WinHTTP functionality. None of this functionality is		*
 * native to Origin C, so the required functionality wrapped in a DLL.			*
 * 																				*
 *------------------------------------------------------------------------------*/
#ifndef __ORESTCLIENT_H__
#define __ORESTCLIENT_H__

#ifdef WIN32 // In VC.
#define EXPORT_SYMBOL __declspec(dllexport)
#ifndef __cplusplus
#define CEXPORT EXPORT_SYMBOL
#else
#define CEXPORT extern "C" EXPORT_SYMBOL
#endif

#include "stdafx.h"

#else // In Origin C.
#define CEXPORT
#ifdef _O64
#pragma dll(orestclient_64, header)
#else
#pragma dll(orestclient, header)
#endif

#endif

enum {
	OREST_ERR_MEMORY_ERROR = -99,	// Memory allocation error.
	OREST_ERR_NOT_EXEC,				// Request not executed yet.
	OREST_ERR_INVALID_URL,			// URL is empty or invalid for some reason.
	OREST_ERR_WIN_HTTP_ERROR,		// Some sort of internal Windows HTTP API error not related
									// to actual connection with server.
									// It would be set prior to connection.
	OREST_ERR_CANNOT_CONNECT,		// Cannot connect to server when sending request.
	OREST_ERR_SSL_ERROR,			// Some sort of issue related to SSL and certificates when sending request.
	OREST_ERR_SEND_RECEIVE_ERROR,	// Any other error when sending data to or receiving data from server.
	OREST_ERR_FILE_ERROR,			// Error saving downloaded file.
	OREST_ERR_PROXY_ERROR,			// Error while resolving potential proxy.
	OREST_ERR_PROXY_REQ_AUTH,		// Proxy requires authentication but no credentials supplied.
	OREST_ERR_PROXY_AUTH_FAIL,		// Proxy authentication failed due to bad credentials.
	OREST_ERR_NO_ERROR = 0,			// No error- successful request.
};

// HTTP request methods.
enum {
	OREST_METHOD_AUTO_GET_OR_POST = 0,	// Use POST of there is a request body otherwise use GET.
	OREST_METHOD_HEAD,
	OREST_METHOD_OPTIONS,
	OREST_METHOD_PUT,
	OREST_METHOD_PATCH,
	OREST_METHOD_DELETE,
};

#define	OREST_DEF_CONNECT_TIMEOUT	60							// Microsoft-suggested default value.
#define	OREST_DEF_SEND_TIMEOUT		30							// Microsoft-suggested default value.
#define	OREST_DEF_RESPONSE_TIMEOUT	30							// Microsoft-suggested default value.
#define	OREST_DEF_HTTP_STATUS		0							// The Default HTTP status set prior to request actually being made.
#define	OREST_STR_DEF_USER_AGENT	"OriginLab-RestClient"		// This is the default user agent for the request.
#define OREST_DEF_IGNORE_SSL_ERRS	false						// Default to not ignore SSL errors.

#define OREST_MEM_ALLOC_SIZE		8196;

#pragma pack(push, 1)
typedef struct {
	int nError;						// [Output] One of the OREST_ERR_* enums. It is same value as returned by ORestClientMakeRequest function.
	int nMethod;					// [Input] One of the OREST_METHOD_* enums.
	LPCSTR lpszUrl;					// [Input] Full URL inc. HTTP scheme, resource variables and query string.
	LPCSTR lpszRequestHeaders;		// [Input] Optional null-terminated string of name:value pairs of request headers seperated by \r\n. Don't include trailing \r\n.
	LPCSTR lpszRequestBody;			// [Input] Optional null-terminated string containing body to send with request (e.g. POST variables).
	LPCSTR lpszUserAgent;			// [Input] Optional null-terminated string containing the User Agent string to use for request.
	int nConnectTimeout;			// [Input] Timeout in seconds.
	int nSendTimeout;				// [Input] Timeout in seconds.
	int nResponseTimeout;			// [Input] Timeout in seconds.
	BOOL bAcceptCompressed;			// [Input] Flag to specify acceptance of compressed response data.
	BOOL bIgnoreSslIssues;			// [Input] Flag to specify that SSL related errors be ignored.
	LPCSTR lpszProxyUser;			// [Input] Optional proxy server authentication user name.
	LPCSTR lpszProxyPassword;		// [Input] Optional proxy server authentication password.
	int nHttpStatus;				// [Output] HTTP response status from the request. Default 0 if no status is returned for some reason.
	LPSTR lpszResponseHeaders;		// [Output] Null-terminated string of name:value pairs of response headers seperated by \r\n. Includes trailing \r\n.
	LPBYTE lpbResponseBody;			// [Output] Byte array containing response body returned from request. NOT null-terminated.
	DWORD dwResponseSize;			// [Output] Count of bytes in response body byte array.
} ORESTCLIENTREQUESTPARAMS;
#pragma pack(pop)

// A note about proxy support:
// Proxy support is a real pain!
// This code does NOT automatically pick up proxy settings from Origin 2019 or greater. (This allows for decoupling
// from the specifics of whatever Origin does- fewer potential issues.)
// Rather, it automatically queries Windows for proxy settings first by looking at those set in the
// Internet Options Control Panel, then for other proxy settings that may be set at the Windows level.
// That being the case, you may still have to provide a proxy user name and password in the struct if
// Windows doesn't have default user name and password settings.

// Origin C callable function that makes the HTTP request.
// Accepts a pointer to an ORESTCLIENTREQUESTPARAMS struct.
// Optionally accepts an integer pointer that can be set to the value
// of Win API GetLastError() in the function (in case it is needed in Origin C).
// Also a debugging param to return amount of memory allocated for response.
// Returns one of OREST_ERR_* enumerations.
// A sucessful request return would be OREST_ERR_NO_ERROR.
// Note: ORestClientCleanRequestParamsStruct MUST be called prior to an instance
// of ORESTCLIENTREQUESTPARAMS going out of scope to avoid memory issues.
CEXPORT int ORestClientMakeRequest(LPVOID pBuf, int* pnGetLastError = NULL, DWORD* pdwAllocated = NULL);

// Origin C callable function that must be called this after calling ORestClientMakeRequest
// to free memory allocated to an instance of ORESTCLIENTREQUESTPARAMS used in that call.
// You cannot free this memory in Origin C due to potential differences
// in the runtime library being used.
CEXPORT int ORestClientCleanRequestParamsStruct(LPVOID pBuf);

// Hashing algorithm types supported by ORestClientGenerateHash.
enum {
	OREST_HASH_MD5 = 0,
	OREST_HASH_SHA1,
	OREST_HASH_SHA256,
	OREST_HASH_SHA384,
	OREST_HASH_SHA512
};

#define OREST_HASH_MD5_HEX_LEN		32
#define OREST_HASH_SHA1_HEX_LEN		40
#define OREST_HASH_SHA256_HEX_LEN	64
#define OREST_HASH_SHA384_HEX_LEN	96
#define OREST_HASH_SHA512_HEX_LEN	128

// Generates a hex string hash based on specified hAlgorithm ID (one of the OREST_HASH_* enums).
// Optionally pass in a secret key string for HMAC calculation.
// Returns length of ressultant string without any NULL terminator or -1 if error.

// Creates hex encoded string hash using one of the OREST_HASH_* algorithm enums
// and optionally accepting a secret string to generate HMAC.
// Returns length of lpzOut without any NULL terminator or -1 if error.
// nOutSize is input param indicating size of buffer to receive result.
CEXPORT int ORestClientGenerateHash(int nAlgId, LPCSTR lpczIn, LPSTR lpzOut, int nOutSize, LPCSTR lpczSecret = NULL);

#define OREST_TIME_FORMAT_BUFSIZE   62 // Same as WINHTTP_TIME_FORMAT_BUFSIZE.

// Converts a pointer to a SYSTEMTIME struct to a date time string formatting to HTTP 1.0 standard.
// Returns 1 on success, 0 on failure.
CEXPORT int ORestClientSystemTimeToHttpTime(const SYSTEMTIME *pst, LPSTR lpszTime);

// Converts a date time string formatted to HTTP 1.0 standard to a pointer to a SYSTEMTIME struct. 
// Returns 1 on success, 0 on failure.
CEXPORT int ORestClientHttpTimeToSystemTime(LPCSTR lpcszTime, SYSTEMTIME *pst);

//#endif //__ORESTCLIENT_H__

#ifndef WIN32 // In Origin C.

#pragma dll() // Closes #pragma dll(orestclient(_64), header) opened above.


// Begin ORestClient class definition.
class ORestClient
{
public:

	ORestClient(LPCSTR lpczUrl = NULL)
	{
		Reset();

		if( lpczUrl )
			SetEndPointUrl(lpczUrl);
	}

	~ORestClient()
	{
	}

	void SetEndPointUrl(const string& strUrl);

	string GetEndPointUrl();

	void ResetEndPointUrl();

	void SetResourceVars(const vector<string>& vsVars);

	bool AddResourceVar(const string& strVar);

	bool ReplaceResourceVar(const string& strVar, const string& strNewVar);

	bool RemoveResourceVar(const string& strVar);

	bool GetResourceVar(string& strVar);

	int GetResourceVars(vector<string>& vsVars);

	void ResetResourceVars();

	bool InsertResourceVarAt(int nIndex, const string& strVar);

	bool ReplaceResourceVarAt(int nIndex, const string& strVar);

	bool RemoveResourceVarAt(int nIndex);

	bool GetResourceVarAt(int nIndex, string& strVar);

	void SetQueryStringVars(const vector<string>& vsNames, const vector<string>& vsValues);

	bool AddQueryStringVar(const string& strName, const string& strValue);

	bool ReplaceQueryStringVar(const string& strName, const string& strValue);

	bool RemoveQueryStringVar(const string& strName);

	bool GetQueryStringVar(const string& strName, string& strValue);

	int GetQueryStringVars(vector<string>& vsNames, vector<string>& vsValues);

	void ResetQueryStringVars();

	void SetPostVars(const vector<string>& vsNames, const vector<string>& vsValues);

	bool AddPostVar(const string& strName, const string& strValue);

	bool ReplacePostVar(const string& strName, const string& strValue);

	bool RemovePostVar(const string& strName);

	bool GetPostVar(const string& strName, string& strValue);

	int GetPostVars(vector<string>& vsNames, vector<string>& vsValues);

	void ResetPostVars();

	void SetRequestBody(const string& strBody);

	string GetRequestBody();

	void ResetRequestBody();

	void SetRequestHeaders(const vector<string>& vsNames, const vector<string>& vsValues);

	bool AddRequestHeader(const string& strName, const string& strValue);

	bool ReplaceRequestHeader(const string& strName, const string& strValue);

	bool RemoveRequestHeader(const string& strName);

	bool GetRequestHeader(const string& strName, string& strValue);

	int GetRequestHeaders(vector<string>& vsNames, vector<string>& vsValues);

	void ResetRequestHeaders();

	void SetAcceptCompressed(bool bCompress);

	bool GetAcceptCompressed();

	void ResetAcceptCompressed();

	void SetUserAgent(const string& strUserAgent);

	string GetUserAgent();

	void ResetUserAgent();

	void SetConnectTimeout(int nTimeout);

	int GetConnectTimeout();

	void ResetConnectTimeout();

	void SetSendTimeout(int nTimeout);

	int GetSendTimeout();

	void ResetSendTimeout();

	void SetReponseTimeout(int nTimeout);

	int GetReponseTimeout();

	void ResetReponseTimeout();

	void SetIgnoreSslIssues(bool bIgnore);

	bool GetIgnoreSslIssues();

	void ResetIgnoreSslIssues();

	void SetProxyCredentials(const string& strUser, const string& strPassword);

	bool GetProxyCredentials(string& strUser, string& strPassword);

	void ResetProxyCredentials();

	int GetError();

	int GetResponseHttpStatus();

	string GetResponseBody();

	bool GetResponseHeader(const string& strName, string& strValue);

	int GetResponseHeaders(vector<string>& vsNames, vector<string>& vsValues);

	string GetExecutionUrl();

	bool Execute(int nMethod = OREST_METHOD_AUTO_GET_OR_POST);

	bool DownloadFile(const string& strFile);

	void Reset();

	void DumpRawResponse();

	string EncodeComponent(const string& strIn);

	string Base64Encode(const string& strIn);

	string GenerateHMAC(int nAlgId, LPCSTR lpczIn, LPCSTR lpczSecret);

	string GenerateHash(int nAlgId, LPCSTR lpczIn);

	string ToHttpTime(const SYSTEMTIME *pst);

	bool FromHttpTime(string strTime, SYSTEMTIME *pst);

protected:
	bool BuildUrl(string& strUrl);

	bool BuildRequestHeadersString(string& strHeaders);

	bool BuildRequestBodyString(string& strBody);

	bool ParseResponseHeaders(const string& strHeaders);

	string DoGenerateHash(int nAlgId, LPCSTR lpczIn, LPCSTR lpczSecret = NULL);

	bool MakeHttpRequest(int nMethod, const string& strFile);

protected:
	string m_strEndPoint;
	string m_strUrl;
	string m_strResponseBody;
	string m_strRequestBody;
	string m_strUserAgent;
	int m_nError;
	int m_nHttpStatus;
	int m_nConnectTimeout;
	int m_nSendTimeout;
	int m_nResponseTimeout;
	vector<string> m_vsQueryNames;
	vector<string> m_vsQueryValues;
	vector<string> m_vsPostNames;
	vector<string> m_vsPostValues;
	vector<string> m_vsResourceVars;
	vector<string> m_vsReqHeaderNames;
	vector<string> m_vsReqHeaderValues;
	vector<string> m_vsRespHeaderNames;
	vector<string> m_vsRespHeaderValues;
	bool m_bIgnoreSslIssues;
	string m_strRawResponseHeaders;
	bool m_bAcceptCompressed;
	string m_strProxyUser;
	string m_strProxyPassword;

private:

}; // end class ORestClient.

void ORestClient::SetEndPointUrl(const string& strUrl)
{
	m_strEndPoint = strUrl;
}

string ORestClient::GetEndPointUrl()
{
	return m_strEndPoint;
}

void ORestClient::ResetEndPointUrl()
{
	m_strEndPoint = "";
}

void ORestClient::SetResourceVars(const vector<string>& vsVars)
{
	m_vsResourceVars = vsVars;
}

bool ORestClient::AddResourceVar(const string& strVar)
{
	// Function expects two vectors & two string, so send copies of each- it's okay.
	vector<string> vsCopy;
	vsCopy = m_vsResourceVars;
	return _AddVar(vsCopy, m_vsResourceVars, strVar, strVar);
}

bool ORestClient::ReplaceResourceVar(const string& strVar, const string& strNewVar)
{
	// Function expects two vectors, so send a copy as first one- it's okay.
	vector<string> vsCopy;
	vsCopy = m_vsResourceVars;
	return _ReplaceVar(vsCopy, m_vsResourceVars, strVar, strNewVar);
}

bool ORestClient::RemoveResourceVar(const string& strVar)
{
	// Function expects two vectors, so send a copy as first one- it's okay.
	vector<string> vsCopy;
	vsCopy = m_vsResourceVars;
	return _RemoveVar(vsCopy, m_vsQueryValues, strVar);
}

bool ORestClient::GetResourceVar(const string& strVar)
{
	// Function expects two vectors & two string, so send copies of each- it's okay.
	vector<string> vsCopy;
	vsCopy = m_vsResourceVars;
	string strCopy = strVar;
	return _GetVarValue(vsCopy, m_vsResourceVars, strCopy, strVar);
}

int ORestClient::GetResourceVars(vector<string>& vsVars)
{
	vsVars = m_vsResourceVars;
	return vsVars.GetSize();
}

void ORestClient::ResetResourceVars()
{
	m_vsResourceVars.SetSize(0);
}

bool ORestClient::InsertResourceVarAt(int nIndex, const string& strVar)
{
	int nSize = m_vsResourceVars.GetSize();

	if( nIndex < 0 || nIndex > nSize - 1 )
		return false;

	m_vsResourceVars.InsertAt(nIndex, strVar, 1);

	return true;
}

bool ORestClient::ReplaceResourceVarAt(int nIndex, const string& strVar)
{
	int nSize = m_vsResourceVars.GetSize();

	if( nIndex < 0 || nIndex > nSize - 1 )
		return false;

	m_vsResourceVars[nIndex] = strVar;

	return true;
}

bool ORestClient::RemoveResourceVarAt(int nIndex)
{
	int nSize = m_vsResourceVars.GetSize();

	if( nIndex < 0 || nIndex > nSize - 1 )
		return false;

	m_vsResourceVars.RemoveAt(nIndex, 1);

	return true;
}

bool ORestClient::GetResourceVarAt(int nIndex, string& strVar)
{
	int nSize = m_vsResourceVars.GetSize();

	if( nIndex < 0 || nIndex > nSize -1 )
		return false;

	strVar = m_vsResourceVars[nIndex];

	return true;
}

void ORestClient::SetQueryStringVars(const vector<string>& vsNames, const vector<string>& vsValues)
{
	m_vsQueryNames.SetSize(0);
	m_vsQueryValues.SetSize(0);

	if( vsValues.GetSize() != vsNames.GetSize() )
		return;

	m_vsQueryNames = vsNames;
	m_vsQueryValues = vsValues;
}

bool ORestClient::AddQueryStringVar(const string& strName, const string& strValue)
{
	return _AddVar(m_vsQueryNames, m_vsQueryValues, strName, strValue);
}

bool ORestClient::ReplaceQueryStringVar(const string& strName, const string& strValue)
{
	return _ReplaceVar(m_vsQueryNames, m_vsQueryValues, strName, strValue);
}

bool ORestClient::RemoveQueryStringVar(const string& strName)
{
	return _RemoveVar(m_vsQueryNames, m_vsQueryValues, strName);
}

bool ORestClient::GetQueryStringVar(const string& strName, string& strValue)
{
	return _GetVarValue(m_vsQueryNames, m_vsQueryValues, strName, strValue);
}

int ORestClient::GetQueryStringVars(vector<string>& vsNames, vector<string>& vsValues)
{
	vsNames = m_vsQueryNames;
	vsValues = m_vsQueryValues;
	return vsNames.GetSize();
}

void ORestClient::ResetQueryStringVars()
{
	m_vsQueryNames.SetSize(0);
	m_vsQueryValues.SetSize(0);
}

void ORestClient::SetPostVars(const vector<string>& vsNames, const vector<string>& vsValues)
{
	m_vsPostNames.SetSize(0);
	m_vsPostValues.SetSize(0);

	m_strRequestBody = "";

	if( vsValues.GetSize() != vsNames.GetSize() )
		return;

	m_vsPostNames = vsNames;
	m_vsPostValues = vsValues;
}

bool ORestClient::AddPostVar(const string& strName, const string& strValue)
{
	m_strRequestBody = "";
	return _AddVar(m_vsPostNames, m_vsPostValues, strName, strValue);
}

bool ORestClient::ReplacePostVar(const string& strName, const string& strValue)
{
	m_strRequestBody = "";
	return _ReplaceVar(m_vsPostNames, m_vsPostValues, strName, strValue);
}

bool ORestClient::RemovePostVar(const string& strName)
{
	return _RemoveVar(m_vsPostNames, m_vsPostValues, strName);
}

bool ORestClient::GetPostVar(const string& strName, string& strValue)
{
	return _GetVarValue(m_vsPostNames, m_vsPostValues, strName, strValue);
}

int ORestClient::GetPostVars(vector<string>& vsNames, vector<string>& vsValues)
{
	vsNames = m_vsPostNames;
	vsValues = m_vsPostValues;
	return vsNames.GetSize();
}

void ORestClient::ResetPostVars()
{
	m_vsPostNames.SetSize(0);
	m_vsPostValues.SetSize(0);
}

void ORestClient::SetRequestBody(const string& strBody)
{
	m_vsPostNames.SetSize(0);
	m_vsPostValues.SetSize(0);

	m_strRequestBody = strBody;
}

string ORestClient::GetRequestBody()
{
	return m_strRequestBody;
}

void ORestClient::ResetRequestBody()
{
	m_strRequestBody = "";
}

void ORestClient::SetRequestHeaders(const vector<string>& vsNames, const vector<string>& vsValues)
{
	m_vsReqHeaderNames.SetSize(0);
	m_vsReqHeaderValues.SetSize(0);

	if( vsValues.GetSize() != vsNames.GetSize() )
		return;

	m_vsReqHeaderNames = vsNames;
	m_vsReqHeaderValues = vsValues;
}

bool ORestClient::AddRequestHeader(const string& strName, const string& strValue)
{
	return _AddVar(m_vsReqHeaderNames, m_vsReqHeaderValues, strName, strValue);
}

bool ORestClient::ReplaceRequestHeader(const string& strName, const string& strValue)
{
	return _ReplaceVar(m_vsReqHeaderNames, m_vsReqHeaderValues, strName, strValue);
}

bool ORestClient::RemoveRequestHeader(const string& strName)
{
	return _RemoveVar(m_vsReqHeaderNames, m_vsReqHeaderValues, strName);
}

bool ORestClient::GetRequestHeader(const string& strName, string& strValue)
{
	return _GetVarValue(m_vsReqHeaderNames, m_vsReqHeaderValues, strName, strValue);
}

int ORestClient::GetRequestHeaders(vector<string>& vsNames, vector<string>& vsValues)
{
	vsNames = m_vsReqHeaderNames;
	vsValues = m_vsReqHeaderValues;
	return vsNames.GetSize();
}

void ORestClient::ResetRequestHeaders()
{
	m_vsReqHeaderNames.SetSize(0);
	m_vsReqHeaderValues.SetSize(0);
}

void ORestClient::SetAcceptCompressed(bool bCompress)
{
	m_bAcceptCompressed = bCompress;
}

bool ORestClient::GetAcceptCompressed()
{
	return m_bAcceptCompressed;
}

void ORestClient::ResetAcceptCompressed()
{
	m_bAcceptCompressed = false;
}

void ORestClient::SetUserAgent(const string& strUserAgent)
{
	m_strUserAgent = strUserAgent;
}

string ORestClient::GetUserAgent()
{
	return m_strUserAgent;
}

void ORestClient::ResetUserAgent()
{
	m_strUserAgent = OREST_STR_DEF_USER_AGENT;
}

void ORestClient::SetConnectTimeout(int nTimeout)
{
	if( nTimeout < 0 )
		nTimeout = 0;

	m_nConnectTimeout = nTimeout;
}

int ORestClient::GetConnectTimeout()
{
	return m_nConnectTimeout;
}

void ORestClient::ResetConnectTimeout()
{
	m_nConnectTimeout = OREST_DEF_CONNECT_TIMEOUT;
}

void ORestClient::SetSendTimeout(int nTimeout)
{
	if( nTimeout < 0 )
		nTimeout = 0;

	m_nSendTimeout = nTimeout;
}

int ORestClient::GetSendTimeout()
{
	return m_nSendTimeout;
}

void ORestClient::ResetSendTimeout()
{
	m_nSendTimeout = OREST_DEF_SEND_TIMEOUT;
}


void ORestClient::SetReponseTimeout(int nTimeout)
{
	if( nTimeout < 0 )
		nTimeout = 0;

	m_nResponseTimeout = nTimeout;
}

int ORestClient::GetReponseTimeout()
{
	return m_nResponseTimeout;
}

void ORestClient::ResetReponseTimeout()
{
	m_nResponseTimeout = OREST_DEF_RESPONSE_TIMEOUT;
}

void ORestClient::SetIgnoreSslIssues(bool bIgnore)
{
	m_bIgnoreSslIssues = bIgnore;
}

bool ORestClient::GetIgnoreSslIssues()
{
	return m_bIgnoreSslIssues;
}

void ORestClient::ResetIgnoreSslIssues()
{
	m_bIgnoreSslIssues = OREST_DEF_IGNORE_SSL_ERRS;
}

void ORestClient::SetProxyCredentials(const string& strUser, const string& strPassword)
{
	m_strProxyUser = strUser;
	m_strProxyPassword = strPassword;
}

bool ORestClient::GetProxyCredentials(string& strUser, string& strPassword)
{
	strUser = m_strProxyUser;
	strPassword = m_strProxyPassword;
	return (!m_strProxyUser.IsEmpty() && !m_strProxyPassword.IsEmpty())
}

void ORestClient::ResetProxyCredentials()
{
	m_strProxyUser = "";
	m_strProxyPassword = "";
}

int ORestClient::GetError()
{
	return m_nError;
}

int ORestClient::GetResponseHttpStatus()
{
	return m_nHttpStatus;
}

string ORestClient::GetResponseBody()
{
	return m_strResponseBody;
}

bool ORestClient::GetResponseHeader(const string& strName, string& strValue)
{
	return _GetVarValue(m_vsRespHeaderNames, m_vsRespHeaderValues, strName, strValue);
}

int ORestClient::GetResponseHeaders(vector<string>& vsNames, vector<string>& vsValues)
{
	vsNames = m_vsRespHeaderNames;
	vsValues = m_vsRespHeaderValues;
	return vsNames.GetSize();
}

string ORestClient::GetExecutionUrl()
{
	string str;
	BuildUrl(str);
	return str;
}

bool ORestClient::Execute(int nMethod)
{
	return ( OREST_ERR_NO_ERROR == MakeHttpRequest(nMethod, "") );
}

bool ORestClient::DownloadFile(const string& strFile)
{
	return ( OREST_ERR_NO_ERROR == MakeHttpRequest(OREST_METHOD_AUTO_GET_OR_POST, strFile) );
}

void ORestClient::Reset()
{
	m_strEndPoint = "";
	m_strUrl = "";
	m_vsResourceVars.SetSize(0);
	m_vsQueryNames.SetSize(0);
	m_vsQueryValues.SetSize(0);
	m_vsPostNames.SetSize(0);
	m_vsPostValues.SetSize(0);
	m_nConnectTimeout = OREST_DEF_CONNECT_TIMEOUT;
	m_nSendTimeout = OREST_DEF_SEND_TIMEOUT;
	m_nResponseTimeout = OREST_DEF_RESPONSE_TIMEOUT;
	m_nError = OREST_ERR_NOT_EXEC;
	m_nHttpStatus = OREST_DEF_HTTP_STATUS;
	m_strUserAgent = OREST_STR_DEF_USER_AGENT;
	m_vsReqHeaderNames.SetSize(0);
	m_vsReqHeaderValues.SetSize(0);
	m_vsRespHeaderNames.SetSize(0);
	m_vsRespHeaderValues.SetSize(0);
	m_bIgnoreSslIssues = OREST_DEF_IGNORE_SSL_ERRS;
	m_strRawResponseHeaders = "";
	m_strResponseBody = "";
	m_strRequestBody = "";
	m_bAcceptCompressed = false;
	m_strProxyUser = "";
	m_strProxyPassword = "";
}

string ORestClient::EncodeComponent(const string& strIn)
{
	const char* pchIn = strIn.GetBuffer(0);

	string strOut;
	char* pchOut = strOut.GetBuffer(3 * strlen(strIn));

	for( ; *pchIn; pchIn++ )
	{
		int i = *pchIn;
		if( (i >= '0' && i <= '9') || (i >= 'A' && i <= 'Z') || (i >= 'a' && i <= 'z') || (i == '~') || (i == '-') || (i == '.') || (i == '_')  )
			sprintf(pchOut, "%c", *pchIn);
		else if( i == ' ' )
		{
			int n = '+';
			sprintf(pchOut, "%c", n);
		}
		else
			sprintf(pchOut, "%%%02X", *pchIn);

		while( *++pchOut );
	}

	strIn.ReleaseBuffer();
	strOut.ReleaseBuffer();

	return strOut;
}

// Adapted from original code by William Sherif (will.sherif@gmail.com): https://github.com/superwills/NibbleAndAHalf
string ORestClient::Base64Encode(const string& strIn)
{
	const char* pch64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/" ;

	int nLength = strlen(strIn);

	if( !nLength )
		return "";

	int nPad = (((nLength % 3) & 1) << 1) + (((nLength % 3) & 2) >> 1);

	const char* pchIn;
	pchIn = strIn.GetBuffer(0);

	string strOut;
	char* pchOut = strOut.GetBuffer((4 *(nLength + nPad) / 3));

	int ii = 0;
	int jj = 0 ;

	for( ii = 0 ; ii <= nLength-3 ; ii += 3 )
	{
		unsigned char CHAR0 = pchIn[ii];
		unsigned char CHAR1 = pchIn[ii+1];
		unsigned char CHAR2 = pchIn[ii+2];
		pchOut[jj++] = pch64[CHAR0 >> 2] ;
		pchOut[jj++] = pch64[((0x3 & CHAR0) << 4) + (CHAR1 >> 4)];
		pchOut[jj++] = pch64[((0x0f & CHAR1) << 2) + (CHAR2 >> 6)];
		pchOut[jj++] = pch64[0x3f & CHAR2];
	}

	if( 2 == nPad )
	{
		pchOut[jj++] = pch64[pchIn[ii] >> 2];
		pchOut[jj++] = pch64[(0x3 & pchIn[ii]) << 4];
		pchOut[jj++] = '=';
		pchOut[jj++] = '=';
	}
	else if( 1 == nPad )
	{
		pchOut[jj++] = pch64[pchIn[ii] >> 2];
		pchOut[jj++] = pch64[((0x3 & pchIn[ii]) << 4) + (pchIn[ii+1] >> 4)];
		pchOut[jj++] = pch64[(0x0f & pchIn[ii+1]) << 2];
		pchOut[jj++] = '=';
	}

	strIn.ReleaseBuffer();
	strOut.ReleaseBuffer();

	return strOut;
}

string ORestClient::GenerateHMAC(int nAlgId, LPCSTR lpczIn, LPCSTR lpczSecret)
{
	return DoGenerateHash(nAlgId, lpczIn, lpczSecret);
}

string ORestClient::GenerateHash(int nAlgId, LPCSTR lpczIn)
{
	return DoGenerateHash(nAlgId, lpczIn, NULL);
}

string ORestClient::ToHttpTime(SYSTEMTIME *pst)
{
	int nSize = (OREST_TIME_FORMAT_BUFSIZE + 1) / sizeof(char);

	string str;
	LPSTR lpsz = str.GetBuffer(nSize);
	memset(lpsz, 0, nSize);

	int nRet = ORestClientSystemTimeToHttpTime(pst, lpsz);

	str.ReleaseBuffer();

	if( !nRet )
		return "";

	return str;
}

bool ORestClient::FromHttpTime(string strTime, SYSTEMTIME *pst)
{
	if( strTime.IsEmpty() )
		return false;

	return ORestClientHttpTimeToSystemTime(strTime, pst);
}

void ORestClient::DumpRawResponse()
{
	printf("Request Error: %d\n\nExecuted URL: %s\n\nResponse HTTP Status: %d\n\nRaw Response Headers: %s\n\n",
			m_nError, m_strUrl, m_nHttpStatus, m_strRawResponseHeaders, m_strResponseBody);

	// May not dump if too big!!!
	printf("Response Body: %s\n", m_strResponseBody);
}

bool ORestClient::BuildUrl(string& strUrl)
{
	if( m_strEndPoint.IsEmpty() )
		return false;

	strUrl = m_strEndPoint;

	strUrl.TrimRight("?");

	int nSize1 = m_vsResourceVars.GetSize();
	if( nSize1 > 0 )
	{
		strUrl.TrimRight("/");
		for( int nn = 0; nn < nSize1; nn++ )
		{
			string strRes = EncodeComponent(m_vsResourceVars[nn]);
			strUrl += "/" + strRes;
		}
	}

	int nSize2 = m_vsQueryNames.GetSize();
	int nSize3 = m_vsQueryValues.GetSize();
	if( nSize2 > 0 && nSize3 >= nSize2)
	{
		strUrl += "?";
		string strName = EncodeComponent(m_vsQueryNames[0]);
		string strValue = EncodeComponent(m_vsQueryValues[0]);
		strUrl += strName + "=" + strValue;

		for( int nn = 1; nn < nSize2; nn++ )
		{
			strName = EncodeComponent(m_vsQueryNames[nn]);
			strValue = EncodeComponent(m_vsQueryValues[nn]);
			strUrl += "&" + strName + "=" + strValue;
		}
	}

	return true;
}

bool ORestClient::BuildRequestHeadersString(string& strHeaders)
{
	vector<string> vsNames, vsValues;
	vsNames = m_vsReqHeaderNames;
	vsValues = m_vsReqHeaderValues;

	int nSize = vsNames.GetSize();
	if( 0 == nSize )
		return false;

	vsValues.SetSize(vsNames.GetSize());

	// Microsoft wants each header to end with \r\n except last one.
	string strName = vsNames[0];
	string strValue = vsValues[0];
	if( !strName.IsEmpty() )
		strHeaders += strName + ":" + strValue;

	for( int ii = 1; ii < nSize; ii++ )
	{
		strName = vsNames[ii];
		strValue = vsValues[ii];
		if( !strName.IsEmpty() )
			strHeaders += "\r\n" + strName + ":" + strValue;
	}

	if( strHeaders.IsEmpty() )
		return false;

	return true;
}

bool ORestClient::BuildRequestBodyString(string& strBody)
{
	if( !m_strRequestBody.IsEmpty() )
	{
		strBody = m_strRequestBody;
		return true;
	}

	int nSize1 = m_vsPostNames.GetSize();
	int nSize2 = m_vsPostValues.GetSize();
	if( nSize1 > 0 && nSize2 >= nSize1)
	{
		strBody = "";
		string strName = EncodeComponent(m_vsPostNames[0]);
		string strValue = EncodeComponent(m_vsPostValues[0]);
		strBody += strName + "=" + strValue;

		for( int nn = 1; nn < nSize1; nn++ )
		{
			strName = EncodeComponent(m_vsPostNames[nn]);
			strValue = EncodeComponent(m_vsPostValues[nn]);
			strBody += "&" + strName + "=" + strValue;
		}

		return true;
	}

	return false;
}

bool ORestClient::ParseResponseHeaders(const string& strHeaders)
{
	m_vsRespHeaderNames.SetSize(0);
	m_vsRespHeaderValues.SetSize(0);
	if( strHeaders.IsEmpty() )
		return false;

	strHeaders.Replace("\r", "");

	vector<string> vsHeaders;
	strHeaders.GetTokens(vsHeaders, '\n');
	int nSize = vsHeaders.GetSize();

	for( int nn = 0; nn < nSize; nn++ )
	{
		string strHeader = vsHeaders[nn];
		if( !strHeader.IsEmpty() && (strHeader.GetNumTokens(':') > 1) )
		{
			string strName = strHeader.GetToken(0, ':');
			string strValue = strHeader.GetToken(1, ':');
			m_vsRespHeaderNames.Add(_str_trim(strName));
			m_vsRespHeaderValues.Add(_str_trim(strValue));
		}
	}

	return m_vsRespHeaderNames.GetSize() > 0;
}

string ORestClient::DoGenerateHash(int nAlgId, LPCSTR lpczIn, LPCSTR lpczSecret)
{
	if (!lpczIn || 0 == strlen(lpczIn))
		return "";

	if (lpczSecret && 0 == strlen(lpczSecret))
		lpczSecret = NULL;

	int nSize;
	switch (nAlgId)
	{
	case OREST_HASH_MD5:
		nSize = OREST_HASH_MD5_HEX_LEN;
		break;

	case OREST_HASH_SHA1:
		nSize = OREST_HASH_SHA1_HEX_LEN;
		break;

	case OREST_HASH_SHA256:
		nSize = OREST_HASH_SHA256_HEX_LEN;
		break;

	case OREST_HASH_SHA384:
		nSize = OREST_HASH_SHA384_HEX_LEN;
		break;

	case OREST_HASH_SHA512:
		nSize = OREST_HASH_SHA512_HEX_LEN;
		break;

	default:
		return ""; // Return empty on unsupported algorithm.
		break;
	}

	nSize++; // Add 1 for NULL terminator.

	string str;
	LPSTR lpsz = str.GetBuffer(nSize);
	memset(lpsz, 0, nSize);

	int nRet = ORestClientGenerateHash(nAlgId, lpczIn, lpsz, nSize, lpczSecret);
	str.ReleaseBuffer();

	if (-1 == nRet)
		return "";

	return str;
}

// If strFile is not empty, valid response will be saved as file. Otherwise response will be output
// to m_strResponseBody property of class.
// Sets and returns the error property to one of the OREST_ERR_ enums described above.
bool ORestClient::MakeHttpRequest(int nMethod, const string& strFile)
{
	ORESTCLIENTREQUESTPARAMS *stParams = new ORESTCLIENTREQUESTPARAMS;
	memset(stParams, 0, sizeof(ORESTCLIENTREQUESTPARAMS));

	stParams->nError = OREST_ERR_NOT_EXEC;
	stParams->nMethod = nMethod;

	if( BuildUrl(m_strUrl) )
		stParams->lpszUrl = m_strUrl;
	else
		stParams->lpszUrl = NULL;

	string strRequestHeaders;
	if( BuildRequestHeadersString(strRequestHeaders) )
		stParams->lpszRequestHeaders = strRequestHeaders;
	else
		stParams->lpszRequestHeaders = NULL;

	string strBody;
	if( BuildRequestBodyString(strBody) )
		stParams->lpszRequestBody = strBody;
	else
		stParams->lpszRequestBody = NULL;

	stParams->lpszUserAgent = m_strUserAgent;
	stParams->nConnectTimeout = m_nConnectTimeout;
	stParams->nSendTimeout = m_nSendTimeout;
	stParams->nResponseTimeout = m_nResponseTimeout;
	stParams->bAcceptCompressed = m_bAcceptCompressed;
	stParams->bIgnoreSslIssues = m_bIgnoreSslIssues;

	if( !m_strProxyUser.IsEmpty() )
		stParams->lpszProxyUser = m_strProxyUser;
	else
		stParams->lpszProxyUser = NULL;

	if( !m_strProxyPassword.IsEmpty() )
		stParams->lpszProxyPassword = m_strProxyPassword;
	else
		stParams->lpszProxyPassword = NULL;

	stParams->nHttpStatus = OREST_DEF_HTTP_STATUS;
	stParams->lpszResponseHeaders = NULL;
	stParams->lpbResponseBody = NULL;
	stParams->dwResponseSize = 0;

	int nGetLastError;
	DWORD dwAllocated;
	ORestClientMakeRequest(stParams, &nGetLastError, &dwAllocated);

	m_nError = stParams->nError;
	m_nHttpStatus = stParams->nHttpStatus;

	m_strRawResponseHeaders = stParams->lpszResponseHeaders;
	ParseResponseHeaders(m_strRawResponseHeaders);
	if( OREST_ERR_NO_ERROR != m_nError || 0 == stParams->dwResponseSize )
	{
		// MUST call this to free memory!
		ORestClientCleanRequestParamsStruct(stParams);
		return m_nError;
	}

	if( !strFile.IsEmpty() )
	{
		file f;
		if ( !f.Open(strFile, file::modeCreate | file::modeWrite | file::shareExclusive) )
			m_nError = OREST_ERR_FILE_ERROR;
		else
		{
			f.Write(stParams->lpbResponseBody, stParams->dwResponseSize * sizeof(byte));
			f.Close();
		}

		// MUST call this to free memory!
		ORestClientCleanRequestParamsStruct(stParams);
		return m_nError;
	}

	// stParams->lpbResponseBody is NOT NULL terminated when returned.
	// So NULL terminate the string.
	LTVarTempChange TEMP("@SCOC", 0); // Forces strign emthods to use bytes.
	string str = stParams->lpbResponseBody;
	m_strResponseBody = str.Left(stParams->dwResponseSize);

	// MUST call this to free memory!
	ORestClientCleanRequestParamsStruct(stParams);

	return m_nError;
}
// End class method implementations.


//Static helper functions.

/*
Returns string trimmed on both sides while leaving original string intact.
*/
static string _str_trim(const string& strIn)
{
	string strOut = strIn;
	strOut.TrimLeft();
	strOut.TrimRight();
	return strOut;
}

/*
Adds a name-value pair to two string vectors.
Returns true if actually added. If already exists, returns false.
Case-insensitive search.
*/
static bool _AddVar(vector<string>& vsNames, vector<string>& vsValues, const string& strName, const string& strValue)
{
	int nIndex = vsNames.Find(strName, 0, false, true, -1);
	if( nIndex >= 0 )
		return false;

	vsNames.Add(strName);
	vsValues.Add(strValue);

	return true;
}

/*
Replaces a value in name-value pair string vectors.
Returns true if actually replaced. If not exists, returns false.
Case-insensitive search.
*/
static bool _ReplaceVar(vector<string>& vsNames, vector<string>& vsValues, const string& strName, const string& strValue)
{
	int nIndex = vsNames.Find(strName, 0, false, true, -1);
	if( nIndex < 0 )
		return false;

	if( vsValues.GetSize() - 1 < nIndex )
		return false;

	vsValues[nIndex] = strValue;

	return true;
}

/*
Removes a name-value pair from two string vectors.
Returns true if actually removed. If not exists, returns false.
Case-insensitive search.
*/
static bool _RemoveVar(vector<string>& vsNames, vector<string>& vsValues, const string& strName)
{
	int nIndex = vsNames.Find(strName, 0, false, true, -1);
	if( nIndex < 0 )
		return false;

	if( vsValues.GetSize() - 1 < nIndex )
		return false;

	vsNames.RemoveAt(nIndex);
	vsValues.RemoveAt(nIndex);

	return true;
}

/*
Returns the value of a name-value pair from two string vectors.
Returns true if actually found. If not exists, returns false.
Case-insensitive search.
*/
static bool _GetVarValue(const vector<string>& vsNames, const vector<string>& vsValues, const string& strName, string& strValue)
{
	if( vsValues.GetSize() < vsNames.GetSize() )
		return false;

	int nIndex = vsNames.Find(strName, 0, false, true, -1);
	if( nIndex < 0 )
		return false;

	strValue = vsValues[nIndex];

	return true;
}

#endif // In Origin C.

#endif //__ORESTCLIENT_H__