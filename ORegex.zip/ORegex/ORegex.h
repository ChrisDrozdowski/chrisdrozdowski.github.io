/*------------------------------------------------------------------------------*
 * File Name: ORegex.h															*
 *																				*
 * Version: 1.0.0																*
 *																				*
 * A library of UTF-8-aware regular expression functions for Origin C.			*
 * Supports returning regex matches as a string vector.							*
 *																				*
 * Created by Chris Drozdowski (drozdowski.chris@gmail.com).					*
 *																				*
 * Licensed under MIT. License info available in project repository				*
 * at https://github.com/chrisdrozdowski.										*
 *																				*
 *------------------------------------------------------------------------------*/
#ifndef __OREGEX_H__
#define __OREGEX_H__

#ifdef WIN32 // In VC.
#define EXPORT_SYMBOL __declspec(dllexport)
#ifndef __cplusplus
#define CEXPORT EXPORT_SYMBOL
#else
#define CEXPORT extern "C" EXPORT_SYMBOL
#endif

#include "stdafx.h"

#else // In Origin C.
#define CEXPORT
#ifdef _O64
#pragma dll(oregex_64, header)
#else
#pragma dll(oregex, header)
#endif

#endif

#define OREGEX_SEP_CHAR		0x07 // ASCII BEL char used as seperator for matches and tokens.


// Potential errors returned from regex function calls.
enum {
	OREGEX_ERR_MEMORY = -99,
	OREGEX_ERR_REGEX
};


// Regex options. Values based on values in Boost.Regex source.
enum ORegexOptions {
	OREGEX_OPTS_DEFAULT = 0,			// My addition- not in source. It specifies using Boos.Regex Perl for grammar.
	OREGEX_OPTS_PERL = 0,				// For Boost.Regex, Perl is same as ECMAScript.
	OREGEX_OPTS_POSIX = 1,
	OREGEX_OPTS_POSIC_EXT = (1 << 8) | (1 << 21) | (1 << 9) | (1 << 16),
	OREGEX_OPTS_ICASE = 1 << 20,
	OREGEX_OPTS_NO_MULTILINE = 1 << 10,	// Turns off multiline support.
	OREGEX_OPTS_NOSUBS = 1 << 22,
};


// Note: By default, the regex functions use ECMAScript regex syntax.

CEXPORT int ORegexValidate(LPCSTR lpczRegex, ORegexOptions opts = OREGEX_OPTS_DEFAULT);

CEXPORT int ORegexTest(LPCSTR lpczIn, LPCSTR lpczRegex, BOOL exact = 0, ORegexOptions opts = OREGEX_OPTS_DEFAULT);

CEXPORT LPCSTR ORegexGetError();

// The Origin C wrappers declared below should be used in place of the following functions because they
// format output in a more friendly manner.
// Note: Must call ORegexCleanMemory after using the following regex functions that have lpzOut parameter
// to free memory allocated for lpzOut.

CEXPORT int ORegexMatch(LPCSTR lpczIn, LPCSTR lpczRegex, LPSTR* lpzOut, ORegexOptions opts = OREGEX_OPTS_DEFAULT);

CEXPORT int ORegexSearch(LPCSTR lpczIn, LPCSTR lpczRegex, LPSTR* lpzOut, ORegexOptions opts = OREGEX_OPTS_DEFAULT);

CEXPORT int ORegexReplace(LPCSTR lpczIn, LPCSTR lpczRegex, LPCSTR lpczRepl, LPSTR* lpzOut, int nStart = -1, int nCount = -1, ORegexOptions opts = OREGEX_OPTS_DEFAULT);

CEXPORT int ORegexSplit(LPCSTR lpczIn, LPCSTR lpczRegex, LPSTR* lpzOut, ORegexOptions opts = OREGEX_OPTS_DEFAULT);

CEXPORT int ORegexCleanMemory(LPSTR lpz);


#ifndef WIN32 // In Origin C.

// In Origin C code.
// ================

#pragma dll() // Closes #pragma dll(oregex(_64), header) opened above.


// Function documentation and Origin C wrapper functions for the regex functions.

// Returns 1 if the regex pattern is valid, otherwise 0.
// May call ORegexGetError if not valid to get text of
// why the regex is invalid.
// int ORegexValidate(LPCSTR lpczRegex, ORegexOptions opts = OREGEX_OPTS_DEFAULT);


// If 'exact' parameter is true, returns 1 if the complete input string
// matches regex, otherwise 0.
// If 'exact' parameter is false, returns 1 if regex is found anywhere
// in the input string, otherwise 0.
// May return one of the OREGEX_ERR_* enums on error.
// int ORegexTest(LPCSTR lpczIn, LPCSTR lpczRegex, BOOL exact = 0, ORegexOptions opts = OREGEX_OPTS_DEFAULT);


// Returns error text that can be assigned to an Origin C string from the
// last error/exception thrown internally by the regex functions.
// Can be called if one of the regex functions returns OREGEX_ERR_REGEX
// to determine the exact nature of the error.
// See documentation for C++ std::regex_error for potential values.
// CEXPORT LPCSTR ORegexGetError();


// Returns count of matches and submatches if the complete input string matches the regex.
// May return one of the OREGEX_ERR_* enums on error.
// Matches and submatches are returned in the string vector reference parameter.
// Regex grammar options may be passed in as well.
int ORegexMatch(const string& strIn, const string& strRegex, vector<string>& vsMatches, ORegexOptions opts = OREGEX_OPTS_DEFAULT)
{
	LPSTR lpzOut;

	int nRet = ORegexMatch(strIn, strRegex, &lpzOut, opts);

	if (nRet > 0 && lpzOut)
	{
		string str = lpzOut;
		//str.GetTokens(vsMatches, OREGEX_SEP_CHAR); // Buggy with double quotes.
		okutil_get_tokens(str, &vsMatches, OREGEX_SEP_CHAR, NULL, '"', GT_IGNORE_QUOTES);
	}

	if (lpzOut)
		ORegexCleanMemory(lpzOut);

	return nRet;
}


// Returns count of matches and submatches for the regex in the input string.
// May return one of the OREGEX_ERR_* enums on error.
// Matches and submatches are returned in the string vector reference parameter.
// Regex grammar options may be passed in as well.
int ORegexSearch(const string& strIn, const string& strRegex, vector<string>& vsMatches, ORegexOptions opts = OREGEX_OPTS_DEFAULT)
{
	LPSTR lpzOut;

	int nRet = ORegexSearch(strIn, strRegex, &lpzOut, opts);

	if (nRet > 0 && lpzOut)
	{
		string str = lpzOut;
		//str.GetTokens(vsMatches, OREGEX_SEP_CHAR); // Buggy with double quotes.
		okutil_get_tokens(str, &vsMatches, OREGEX_SEP_CHAR, NULL, '"', GT_IGNORE_QUOTES);
	}

	if (lpzOut)
		ORegexCleanMemory(lpzOut);

	return nRet;
}

// Replaces regex matches in the input string with a replacement string.
// Optionally specify a zero-based starting index of matches to replace and/or
// count of replacements to make.
// Returns number of replacements or one of the OREGEX_ERR_* enums on error.
// The replacement may be a string or even a regex.
// The strOut reference parameter will contain the string after replacements.
// Regex grammar options may be passed in as well.
int ORegexReplace(const string& strIn, const string& strRegex, const string& strRepl, string& strOut, int nStart = -1, int nCount = -1, ORegexOptions opts = OREGEX_OPTS_DEFAULT)
{
	LPSTR lpzOut;

	int nRet = ORegexReplace(strIn, strRegex, strRepl, &lpzOut, nStart, nCount, opts);

	if (nRet >= 0 && lpzOut)
		strOut = lpzOut;

	if (lpzOut)
		ORegexCleanMemory(lpzOut);

	return nRet;
}


// Splits input string into tokens using regex matches as the seperator.
// Returns number of tokens or one of the OREGEX_ERR_* enums on error.
// Tokens are returned in the string vector reference parameter.
// Regex grammar options may be passed in as well.
int ORegexSplit(const string& strIn, const string& strRegex, vector<string>& vsTokens, ORegexOptions opts = OREGEX_OPTS_DEFAULT)
{
	LPSTR lpzOut;

	int nRet = ORegexSplit(strIn, strRegex, &lpzOut, opts);

	if (nRet > 0 && lpzOut)
	{
		string str = lpzOut;
		//str.GetTokens(vsTokens, OREGEX_SEP_CHAR); // Buggy with double quotes.
		okutil_get_tokens(str, &vsTokens, OREGEX_SEP_CHAR, NULL, '"', GT_IGNORE_QUOTES);
	}

	if (lpzOut)
		ORegexCleanMemory(lpzOut);

	return nRet;
}

// End Origin C wrapper functions.


#endif // Last #ifndef WIN32.

#endif //__OREGEX_H__
