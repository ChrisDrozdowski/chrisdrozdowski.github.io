#include <Origin.h>
#include "./ORound.h"

// This file exists only to include ORound.h which makes the ORound
// functions available in LabTalk (e.g. Set Column Values formulae).
// This file should be added to the User [Autoload] workspace in Code
// Builder so that it gets automatically compiled.

// If you are calling the ORound functions from Origin C only, you do not
// need to add this file to User [Autoload] workspace. You would simply
// #include ORound.h in your Origin C source code file.

// Of course, it is all right to have this file automatically compiled
// by User [Autoload] and #include ORound.h in your Origin C source
// code at the same time. They can coexist just fine.
