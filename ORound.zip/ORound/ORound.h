/*------------------------------------------------------------------------------*
* File Name: ORound.h															*
*																				*
* Version: 0.9.0																*
*																				*
* A library of rounding functions for Origin C.									*
*																				*
* Created by Chris Drozdowski (drozdowski.chris@gmail.com).						*
*																				*
* Licensed under MIT. License info available in project repository				*
* at https://github.com/chrisdrozdowski.										*
*																				*
*------------------------------------------------------------------------------*/
#ifndef __OROUND_H__
#define __OROUND_H__

#ifdef WIN32 // In VC.
#define EXPORT_SYMBOL __declspec(dllexport)
#ifndef __cplusplus
#define CEXPORT EXPORT_SYMBOL
#else
#define CEXPORT extern "C" EXPORT_SYMBOL
#endif

#include "stdafx.h"

#else // In Origin C.
#define CEXPORT
#ifdef _O64
#pragma dll(oround_64, header)
#else
#pragma dll(oround, header)
#endif

#endif


// Rounds value to arbitrary decimal places. If digits after decimals is a
// halfway value, rounds to nearest even number.
// Otherwise rounds up away from zero symmetrically.
// Known as "round half even", "bankers", or " convergent" rounding.
CEXPORT double ORoundE(double value, int decimals = 0);

// Rounds value to arbitrary decimal places. If digits after decimals is a
// halfway value, rounds up away from zero symmetrically.
CEXPORT double ORoundU(double value, int decimals = 0);

// Rounds value to arbitrary decimal places. If digits after decimals is a
// halfway value, rounds down towards zero symmetrically.
CEXPORT double ORoundD(double value, int decimals = 0);

// Rounds value to arbitrary decimal places. If digits after decimals is a
// halfway value, rounds up away from or downtowards zero symmetrically based
// on the value of a randomly generated number.
CEXPORT double ORoundR(double value, int decimals = 0);

// Rounds value to arbitrary decimal places. If digits after decimals is a
// halfway value, rounds up away from ordown  towards zero  symmetrically
// based on the optional 'up' parameter which defaults to true meaning up away from zero.
CEXPORT double ORoundA(double value, int decimals = 0, bool up = true);

// Rounds value to arbitrary decimal places. Uses probability to determine whether
// to round up away or down towards zero symmetrically. If digits after decimals
// is a halfway value, uses random rounding.
// Known as "stochastic" rounding.
CEXPORT double ORoundS(double value, int decimals = 0);

// Rounds to nearest value that is a multiple of the specified base. Uses round up away from zero.
// 'base' parameter specfies base: 0=natural log (e); 2=base 2; 10=base 10; default 0=natural log (e).
CEXPORT double ORoundL(double value, unsigned int base = 0);

// Rounds to nearest value that is a multiple of the 'multiple' parameter. Uses round up away from zero.
CEXPORT double ORoundM(double value, double multiple = 1.0);


// The functions below are the vector versions of the above functions. The 'pvout' parameter will
// return the rounded values and MUST be initialized to the same size as in input vector, 'pvin'.
// That size is passed in to the 'len' parameter.

// !!! It is better to use the overloaded Origin C functions defined later in this file.

CEXPORT unsigned int ORoundE_Ex(const double *pvin, double *pvout, unsigned int len, int decimals = 0);
CEXPORT unsigned int ORoundU_Ex(const double *pvin, double *pvout, unsigned int len, int decimals = 0);
CEXPORT unsigned int ORoundD_Ex(const double *pvin, double *pvout, unsigned int len, int decimals = 0);
CEXPORT unsigned int ORoundR_Ex(const double *pvin, double *pvout, unsigned int len, int decimals = 0);
CEXPORT unsigned int ORoundA_Ex(const double *pvin, double *pvout, unsigned int len, int decimals = 0, bool up = true);
CEXPORT unsigned int ORoundS_Ex(const double *pvin, double *pvout, unsigned int len, int decimals = 0);
CEXPORT unsigned int ORoundL_Ex(const double *pvin, double *pvout, unsigned int len, unsigned int base = 0);
CEXPORT unsigned int ORoundM_Ex(const double *pvin, double *pvout, unsigned int len, double multiple = 1.0);


#ifndef WIN32 // In Origin C.

// In Origin C code.
// ================

#pragma dll() // Closes #pragma dll(oround(_64), header) opened above.


// Overloaded functions.

// For functions below that accept vector input- have to pass by value
// because a bug was introduced into Origin 2019 that corrupts input data
// if const references to column data are used.

// Vector form of ORoundE (see above).
vector<double> ORoundE(vector<double> vecIn, int decimals = 0)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundE_Ex(vecIn, vecOut, vecIn.GetSize(), decimals);
	return vecOut;
}

// Vector form of ORoundU (see above).
vector<double> ORoundU(vector<double> vecIn, int decimals = 0)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundU_Ex(vecIn, vecOut, vecIn.GetSize(), decimals);
	return vecOut;
}

// Vector form of ORoundD (see above).
vector<double> ORoundD(vector<double> vecIn, int decimals = 0)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundD_Ex(vecIn, vecOut, vecIn.GetSize(), decimals);
	return vecOut;
}

// Vector form of ORoundR (see above).
vector<double> ORoundR(vector<double> vecIn, int decimals = 0)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundR_Ex(vecIn, vecOut, vecIn.GetSize(), decimals);
	return vecOut;
}

// Vector form of ORoundA (see above).
vector<double> ORoundA(vector<double> vecIn, int decimals = 0, bool up = true)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundA_Ex(vecIn, vecOut, vecIn.GetSize(), decimals, up);
	return vecOut;
}

// Vector form of ORoundS (see above).
vector<double> ORoundS(vector<double> vecIn, int decimals = 0)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundS_Ex(vecIn, vecOut, vecIn.GetSize(), decimals);
	return vecOut;
}

// Vector form of ORoundL (see above).
vector<double> ORoundL(vector<double> vecIn, int base = 0)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundL_Ex(vecIn, vecOut, vecIn.GetSize(), base);
	return vecOut;
}

// Vector form of ORoundM (see above).
vector<double> ORoundM(vector<double> vecIn, double multiple = 1.0)
{
	int nSize = vecIn.GetSize();
	vector<double> vecOut(nSize);
	ORoundM_Ex(vecIn, vecOut, vecIn.GetSize(), multiple);
	return vecOut;
}


//END OC CODE


#endif // Last #ifndef WIN32.

#endif //__OROUND_H__
